using System.IO;
using CodeProgression.CodeCamp.MassTransit.Common;
using log4net;
using log4net.Config;
using MassTransit;
using MassTransit.Transports.Msmq;
using StructureMap;
using Topshelf;
using Topshelf.Configuration;
using Topshelf.Configuration.Dsl;

namespace CodeProgression.CodeCamp.MassTransit.Server
{
    internal class Program
    {
        private static readonly ILog Log = LogManager.GetLogger(typeof (Program));

        private static void Main(string[] args)
        {
            XmlConfigurator.ConfigureAndWatch(new FileInfo("server.log4net.xml"));
            Log.Info("Server Loading"); 

            RunConfiguration cfg = RunnerConfigurator.New(c =>
                {
                    c.SetServiceName("PasswordUpdateService");
                    c.SetDisplayName("Password Update Service");
                    c.SetDescription("Updates passwords via message bus");
                    c.DependencyOnMsmq();
                    c.RunAsLocalSystem();

                    MsmqEndpointConfigurator.Defaults(x => { x.CreateMissingQueues = true; });


                    var container = new Container(x => x.AddRegistry(new CommonRegistry("msmq://localhost/mt_server")));

                    c.ConfigureService<PasswordUpdateService>(s =>
                        {
                            s.WhenStarted(o => o.Start(container.GetInstance<IServiceBus>()));
                            s.WhenStopped(o => o.Stop());
                            s.HowToBuildService(builder => container.GetInstance<PasswordUpdateService>());
                        });
                });
            Runner.Host(cfg, args);
        }
    }
}