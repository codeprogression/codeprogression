using System;
using System.Threading;
using CodeProgression.CodeCamp.MassTransit.Common.Messages;
using MassTransit;
using MassTransit.Internal;

namespace CodeProgression.CodeCamp.MassTransit.Client
{
    public class ClientService : IBusService
    {
        private IServiceBus _bus;
        private UnsubscribeAction _unsubscribeAction;

        public void Start(IServiceBus bus)
        {
            _bus = bus;
            _unsubscribeAction = _bus.Subscribe<PasswordUpdater>();
            while (true)
            {
                Console.WriteLine(new string('-', 20));
                Console.WriteLine("New Password Client");
                Console.WriteLine("What would you like to set your new password to?");
                Console.Write("New Password:");
                var newPassword = Console.ReadLine();

                Console.WriteLine(new string('-', 20));

                var message = new RequestPasswordUpdate(newPassword);

                _bus.Publish(message);

                Console.WriteLine("Waiting For Reply");
                Console.WriteLine(new string('-', 20));
                Console.WriteLine();
                Thread.Sleep(2000);
                Console.WriteLine("Press [Enter] to restart client.");
                if (Console.ReadLine() == "q") break;
                Console.Clear();
            }
        }

        public void Stop()
        {
            _unsubscribeAction();
        }

        public void Dispose()
        {
            _bus.Dispose();
        }
    }
}