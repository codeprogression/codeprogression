using CodeProgression.CodeCamp.MassTransit.Common.Messages;
using log4net;
using MassTransit;

namespace CodeProgression.CodeCamp.MassTransit.Client
{
    public class PasswordUpdater :
        Consumes<PasswordUpdateComplete>.All
    {
        private static readonly ILog Log = LogManager.GetLogger(typeof(PasswordUpdater));

        public void Consume(PasswordUpdateComplete message)
        {
            Log.InfoFormat("Global password update complete: {0} ({1})", message.ErrorCode, message.CorrelationId);
        }
    }
}