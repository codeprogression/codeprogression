using System.IO;
using CodeProgression.CodeCamp.MassTransit.Common;
using log4net.Config;
using StructureMap;
using Topshelf.Configuration.Dsl;
using log4net;
using MassTransit;
using Topshelf;

namespace CodeProgression.CodeCamp.MassTransit.Client
{
    internal class Program
    {
        private static readonly ILog Log = LogManager.GetLogger(typeof(Program));

        private static void Main(string[] args)
        {
            XmlConfigurator.ConfigureAndWatch(new FileInfo("log4net.xml"));
            Log.Info("Server Loading");

            var cfg = RunnerConfigurator.New(c =>
                {
                    c.SetServiceName("PasswordClientService");
                    c.SetDisplayName("Password Client Service");
                    c.SetDescription("Passes password reset request to bus.");
                    c.DependencyOnMsmq();
                    c.RunAsLocalSystem();

                    var container = new Container(new CommonRegistry("msmq://localhost/mt_client"));

                    c.ConfigureService<ClientService>(service =>
                        {
                            service.WhenStarted(o => o.Start(container.GetInstance<IServiceBus>()));
                            service.WhenStopped(o => o.Stop());
                            service.HowToBuildService(builder => container.GetInstance<ClientService>());
                        });
                });
            Runner.Host(cfg, args);
        }
    }
}