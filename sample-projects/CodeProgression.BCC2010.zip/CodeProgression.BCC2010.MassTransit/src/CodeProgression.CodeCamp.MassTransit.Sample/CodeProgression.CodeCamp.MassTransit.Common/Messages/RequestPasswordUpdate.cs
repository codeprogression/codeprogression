using System;
using MassTransit;

namespace CodeProgression.CodeCamp.MassTransit.Common.Messages
{
    [Serializable]
    public class RequestPasswordUpdate :
        CorrelatedBy<Guid>
    {
        public RequestPasswordUpdate(string newPassword)
        {
            CorrelationId = Guid.NewGuid();
            NewPassword = newPassword;
        }

        protected RequestPasswordUpdate()
        {
        }

        public string NewPassword { get; set; }

        public Guid CorrelationId { get; set; }
    }
}