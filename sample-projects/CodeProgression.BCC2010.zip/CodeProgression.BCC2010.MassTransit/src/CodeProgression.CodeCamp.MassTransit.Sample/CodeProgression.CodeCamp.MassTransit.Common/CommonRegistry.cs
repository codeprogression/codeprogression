using MassTransit.Services.Subscriptions.Configuration;
using MassTransit.StructureMapIntegration;
using MassTransit.Transports.Msmq;

namespace CodeProgression.CodeCamp.MassTransit.Common
{
    public class CommonRegistry : MassTransitRegistryBase
    {
        public CommonRegistry(string endpointUri) : base(typeof(MsmqEndpoint))
        {
            RegisterServiceBus(endpointUri,x=> x.ConfigureService<SubscriptionClientConfigurator>(
                                                   config =>
                                                   config.SetSubscriptionServiceEndpoint(
                                                       "msmq://localhost/mt_subscriptions")));

            MsmqEndpointConfigurator.Defaults(config => { config.CreateMissingQueues = true; });
        }
    }
}