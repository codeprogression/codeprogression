using System;
using NServiceBus;

namespace CodeProgression.BCC2010.Core.Messages
{
    public class ChangeMyPassword : IMessage
    {
        public Guid Id { get; set; }
        public string Password{ get; set;}
    }
}