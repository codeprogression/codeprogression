using System;
using NServiceBus;

namespace CodeProgression.BCC2010.Core.Messages
{
    public class PasswordUpdateComplete:IMessage
    {
        public Guid CorrelationId { get; set; }
    }
    public class PasswordUpdateFailed:IMessage
    {
        public Guid CorrelationId { get; set; }
    }
}