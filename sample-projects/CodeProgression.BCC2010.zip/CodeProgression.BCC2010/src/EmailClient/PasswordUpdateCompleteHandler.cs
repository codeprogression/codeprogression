using System;
using CodeProgression.BCC2010.Core.Messages;
using NServiceBus;

namespace CodeProgression.BCC2010.EmailClient
{
    public class PasswordUpdateCompleteHandler:IHandleMessages<PasswordUpdateComplete>
    {
        public void Handle(PasswordUpdateComplete message)
        {
            Console.WriteLine("Sent email about request id" + message.CorrelationId);
        }
    }
}