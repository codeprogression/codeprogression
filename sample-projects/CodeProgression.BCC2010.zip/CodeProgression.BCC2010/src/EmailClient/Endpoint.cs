using System;
using CodeProgression.BCC2010.Core.Messages;
using NServiceBus;

namespace CodeProgression.BCC2010.EmailClient
{
    public class Endpoint:IConfigureThisEndpoint, AsA_Client, IWantToRunAtStartup
    {
        public void Run()
        {
            Console.Title = "Email Client";
            Bus.Subscribe<PasswordUpdateComplete>();
        }

        public IBus Bus { get; set; }

        public void Stop()
        {
        }
    }
}