using System;
using CodeProgression.BCC2010.Core.Messages;
using NServiceBus;

namespace CodeProgression.BCC2010.Client
{
    public class Endpoint : IConfigureThisEndpoint, AsA_Client, IWantToRunAtStartup
    {
        public void Run()
        {
            Console.Title = "Client";
            while (true)
            {
                Console.WriteLine("what is your new password?");
                var passwordrequest = Console.ReadLine();

                var myPassword = new ChangeMyPassword 
                    {Id = Guid.NewGuid(), Password = passwordrequest};
                Bus.Send(myPassword)
                .Register(PasswordChangedCallback, myPassword);
            

                Console.WriteLine("Press Enter to continue.");
                Console.ReadLine();
            }
        }

        private void PasswordChangedCallback(IAsyncResult ar)
        {
            var result = (CompletionResult) ar.AsyncState;
            Console.WriteLine(result.Messages[0] is PasswordUpdateComplete ? "Successful" : "Failed");
        }


        public IBus Bus { get; set; }

        public void Stop()
        {
        }
    }
}