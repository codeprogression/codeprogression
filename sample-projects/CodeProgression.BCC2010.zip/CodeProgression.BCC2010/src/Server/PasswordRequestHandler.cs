using System;
using CodeProgression.BCC2010.Core.Messages;
using NServiceBus;

namespace CodeProgression.BCC2010.Server
{
    public class PasswordRequestHandler:IHandleMessages<ChangeMyPassword>
    {
        public void Handle(ChangeMyPassword message)
        {
            Console.WriteLine("Changed password to "+message.Password);
            
            if (string.IsNullOrEmpty(message.Password))
            {
                var updateFailed = new PasswordUpdateFailed { CorrelationId = message.Id };
                Bus.Reply(updateFailed);
                Bus.Publish(updateFailed);
            }
        else
            {
                var completeMessage = new PasswordUpdateComplete {CorrelationId = message.Id};

                Bus.Reply(completeMessage);
                Bus.Publish(completeMessage);
            }
        }

        public IBus Bus { get; set; }
    }
}