using System;
using System.Collections.Generic;
using NServiceBus;

namespace CodeProgression.BCC2010.Server
{
    public class AuthorizeSubscriptions:IAuthorizeSubscriptions
    {
        public bool AuthorizeSubscribe(string messageType, string clientEndpoint, string clientWindowsIdentity, IDictionary<string, string> headers)
        {
            return true;    
        }

        public bool AuthorizeUnsubscribe(string messageType, string clientEndpoint, string clientWindowsIdentity, IDictionary<string, string> headers)
        {
            return true;
        }
    }
}