using System;
using NServiceBus;

namespace CodeProgression.BCC2010.Server
{
    public class Endpoint: IConfigureThisEndpoint, AsA_Publisher, IWantToRunAtStartup
    {
        public void Run()
        {
            Console.Title = "Server";
        }

        public void Stop()
        {
        }
    }
}