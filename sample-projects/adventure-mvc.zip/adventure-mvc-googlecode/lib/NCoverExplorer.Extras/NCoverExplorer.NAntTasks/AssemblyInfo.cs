using System.Reflection;

[assembly: AssemblyTitle("NCoverExplorer.NAntTasks")]
[assembly: AssemblyDescription("NAnt tasks for executing NCover, NCoverExplorer.Console, NUnit and NDoc2 in continuous build processes.")]
[assembly: AssemblyCompany("KiwiNova Ltd")]
[assembly: AssemblyCopyright("Copyright � 2007 KiwiNova Ltd.")]
[assembly: AssemblyProduct("NCoverExplorer NAnt Tasks")]
[assembly: AssemblyVersion("1.4.0.5")]
