namespace MvcContrib.Samples.FormHelper.Models
{
	public enum Gender
	{
		Female,
		Male
	}
}