namespace NinjectControllerFactory.Domain
{
    public interface IWeapon
    {
        string Hit(string target);
    }
}
