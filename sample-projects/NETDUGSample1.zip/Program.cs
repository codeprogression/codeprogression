﻿using System;
using System.Collections.Generic;
using AutoMapper;
using NETDUGSample.DTO;
using NETDUGSample.Entity;
using NETDUGSample.Registry;

namespace NETDUGSample
{
    public class Program
    {
        private static void Main(string[] args)
        {
            var before = 0;
            var after = 0;

            var meeting = new Meeting()
                              {
                                  Begins = DateTime.Now,
                                  End = DateTime.Now.AddHours(1),
                                  Attendees = new List<string>()
                                                  {
                                                      "Cory", "Richard", "Chris"
                                                  },
                                  Title = "I Dont Care!"
                              };

            #region 1. old school, classic method

//            var dto = new MeetingDto();
//            dto.Begins = meeting.Begins;
//            dto.End = meeting.End;
//            dto.Attendees = meeting.Attendees;

            #endregion

            #region  2. Inline Option 

            //Mapper.Reset();
//            Mapper.CreateMap<Meeting, MeetingDto>()
//                .BeforeMap((src, dest) => before++)
//                .AfterMap((src, dest) => after++)
//                .ForMember(d => d.LengthInMinutes, o => o.Ignore());

            //Mapper.AssertConfigurationIsValid();


            #endregion

            #region 3. Registry Option

             AutomapperRegistry.Configure();

            #endregion

            var dto = Mapper.Map<Meeting, MeetingDto>(meeting);

            Console.WriteLine("Meeting Begins:" + meeting.Begins);
            Console.WriteLine("Meeting Attendee Count:" + meeting.Attendees.Count);
            Console.WriteLine("MeetingDto Begins:" + dto.Begins);
            Console.WriteLine("MeetingDto Attendee Count:" + dto.Attendees.Count);
            Console.WriteLine("BeforeCount:" + before);
            Console.WriteLine("AfterCount:" + after);

            Console.ReadLine();
        }
    }
}
