﻿using AutoMapper;
using NETDUGSample.DTO;
using NETDUGSample.Entity;

namespace NETDUGSample.MappingProfile
{
    public class MeetingProfile : Profile
    {
        protected override string ProfileName
        {
            get { return "MeetingProfile"; }
        }

        protected override void Configure()
        {
            CreateMap<Meeting, MeetingDto>()
                .ForMember(d => d.LengthInMinutes, o => o.Ignore());
        }
    }
}