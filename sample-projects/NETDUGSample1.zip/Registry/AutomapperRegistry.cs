﻿using AutoMapper;
using NETDUGSample.DTO;
using NETDUGSample.Entity;
using NETDUGSample.MappingProfile;

namespace NETDUGSample.Registry
{
    public class AutomapperRegistry
    {
        public static void Configure()
        {
            // ReUsable Mapping Profiles
            Mapper.Initialize(x =>
            {
                x.AddProfile<MeetingProfile>();
            });

            // Simple Maps
            //Mapper.CreateMap<Meeting, MeetingDto>()
            //    .ForMember(d => d.LengthInMinutes, o => o.Ignore()); 

            // Verify Mappings
            Mapper.AssertConfigurationIsValid();
        }
    }
}