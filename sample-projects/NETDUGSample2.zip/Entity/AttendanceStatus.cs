namespace NETDUGSample.Entity
{
    public enum AttendanceStatus
    {
        Pending,
        Rejected,
        Confirmed,
    }
}