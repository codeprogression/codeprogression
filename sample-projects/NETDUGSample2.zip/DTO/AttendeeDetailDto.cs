namespace NETDUGSample.DTO
{
    public class AttendeeDetailDto
    {
        public int Id;
        public string FirstName;
        public string LastName;
        public string EmailAddress;
        public string WebPage;
        public string Status;
    }
}