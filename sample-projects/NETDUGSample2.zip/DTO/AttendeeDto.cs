namespace NETDUGSample.DTO
{
    public class AttendeeDto
    {
        public int Id;
        public string FullName;
    }
}